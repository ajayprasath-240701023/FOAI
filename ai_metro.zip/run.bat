@echo off
echo ========================================================
echo  AI METRO -- SCADA Transit Control Room ^& Multi-Agent AI
echo ========================================================
echo.
echo [1/2] Checking dependencies...
pip install -r requirements.txt --quiet
echo [2/2] Starting server...
echo.
echo  Access Control Room at:  http://localhost:8000
echo  Stop server with:        Ctrl+C
echo.
cd backend
python -m uvicorn api:app --host 127.0.0.1 --port 8000 --reload
