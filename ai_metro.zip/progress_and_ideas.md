# AI Metro — Complete Project History, Requirements, and Ideas Roadmap

> **Document Type:** Comprehensive Project Overview, Chronological Progress Log & Ideas Roadmap  
> **Project Name:** AI Metro — Crowd-Aware Metro Route Planner  
> **Core Engine:** A* (A-Star) Multi-Criteria Heuristic Search  
> **Repository Location:** `C:\Users\ajayp\.gemini\antigravity-ide\scratch\ai_metro`  

---

## 1. Executive Summary & Original Vision

### 1.1 The Problem Statement
Conventional metro navigation engines (e.g., Google Maps, transit apps) primarily compute shortest path or fastest travel time based purely on physical track distance and average train speed. In real-world urban transit, this approach suffers from significant flaws:
1. **Ignoring Crowd Levels:** A route that is 2 minutes faster may subject commuters to severely packed stations and trains, leading to platform delays, missed boarding, and poor travel comfort.
2. **Transfer Friction:** Frequent line changes introduce physical fatigue, platform navigation delays, and increased connection risks, which simple distance-based algorithms undervalue.
3. **Static Availability:** Real networks experience station maintenance, track disruptions, platform closures, and temporary line outages. Routing engines must treat closed stations as strict non-traversable hard constraints, instantly recalculating alternatives.

### 1.2 The Core Objective
The objective of **AI Metro** is to build a full-stack, transparent, and interactive prototype of a crowd-aware metro route planner. Rather than treating route planning as a black-box library call, the system explicitly implements **A\* Search** from first principles, integrating four dynamic cost parameters into an admissible evaluation function:
- **Travel Cost / Base Fare (₹)**
- **Travel Time (minutes)**
- **Station Crowd Levels (Low, Medium, High penalties)**
- **Line Transfer Friction (penalty for switching lines)**

The application provides an interactive dark-mode glassmorphism interface featuring dynamic crowd simulation, station disruption toggling, alternative route discovery (Yen’s algorithm), and a step-by-step visual A* trace animator illustrating open and closed set state transitions.

---

## 2. What We Were Supposed to Do From the Start

The initial specification required a complete, self-contained, and demonstrable software architecture:

### 2.1 Metro Network Specification
- **20 Physical Stations** positioned on an intuitive 2D coordinate grid.
- **3 Color-Coded Transit Lines**:
  - **Blue Line (East-West / Horizontal):** 8 stations  
    `West Terminal → Westwood Park → University Gate → Central Hub → Market Plaza → Riverside → Tech Valley → East Terminal`
  - **Red Line (North-South / Vertical):** 7 stations  
    `Northern Heights → Industrial Zone → Suburban North → Central Hub → Old Town → Harbour View → South Terminal`
  - **Green Line (Southwest-Northeast / Diagonal):** 8 stations  
    `Airport → Expo Centre → Old Town → Cultural Hub → Market Plaza → Science Park → IT Hub → North Connect`
- **3 Major Interchange Hubs**:
  - **Central Hub:** Interchange between Blue & Red Lines
  - **Market Plaza:** Interchange between Blue & Green Lines
  - **Old Town:** Interchange between Red & Green Lines
- **20 Bidirectional Track Segments:** Stored as 40 directed edges internally with explicit travel times (3–7 min) and fares (₹8–₹18).

### 2.2 Mathematical Model & Search Algorithm
1. **Search State Representation:**
   $$\text{State} = (\text{station\_id}, \text{current\_line})$$
   *Tracking the arrival line within the search state is mandatory to accurately calculate line transfer penalties at interchange hubs.*

2. **Cost Function $g(n)$:**
   $$g(n) = \sum_{e \in \text{path}} \text{edge\_cost}(e)$$
   $$\text{edge\_cost} = w_{\text{cost}} \cdot \text{fare} + w_{\text{time}} \cdot \text{time} + w_{\text{crowd}} \cdot \text{crowd\_penalty} + w_{\text{transfer}} \cdot \text{transfer\_penalty}$$
   - **Crowd Penalties:** Low = 0, Medium = 8, High = 20
   - **Transfer Penalty:** 0 (same line), 25 (line change)
   - User preference weights ($w_i$) range from $0.0$ to $2.0$ (normalized or balanced).

3. **Heuristic Function $h(n)$ & Admissibility:**
   $$h(n) = \text{Euclidean Distance}(n, \text{goal}) \times 0.05$$
   - **Admissibility Proof:** The shortest edge in the network is approximately 75–80 pixels, with a minimum cost of $\ge 5.5$ units at base weight $0.5$. With scaling factor $0.05$, $h(75) = 3.75 \le 5.5$. Because $h(n) \le h^*(n)$ for all nodes, the heuristic never overestimates the remaining cost, ensuring A* guarantees optimality.

4. **Tie-Breaking Priority Queue:**
   - Standard min-heap (`heapq`) storing tuples `(f, tie_breaker, station_id, line, g, path_stations, path_lines)` to avoid unhashable comparison errors when $f(n)$ values are identical.

5. **Alternative Route Discovery:**
   - Implementation of a simplified Yen’s K-shortest path algorithm: computing the primary optimal path $P_1$, systematically removing intermediate stations/edges to re-run A*, and returning the highest-ranked alternative path $P_2$.

6. **Hard-Constraint Availability Filtering:**
   - Inactive stations or closed tracks are strictly filtered out of the graph neighbor generator before cost evaluation, preventing the search from traversing disrupted infrastructure.

### 2.3 Frontend & UI Requirements
- Clean, responsive 3-column layout:
  - **Left Panel:** Station selectors (Origin/Destination), customizable weight sliders, quick preset buttons (Fastest, Cheapest, Comfort, Balanced), and network legend.
  - **Center Panel:** Interactive network graph visualization displaying real-time station statuses, line colors, and active route paths.
  - **Right Panel:** Route metrics breakdown (time, fare, transfers, crowd rating), step-by-step route directions, A* trace inspector table and playback animator, and disruption toggles.
- Zero heavyweight JS frameworks (pure HTML5, Vanilla CSS3, Vanilla JavaScript).

---

## 3. Complete Chronological Progress History

```mermaid
timeline
    title AI Metro Project Evolution
    Initial Design & Backend : Data schema & 20-station JSON
                             : Graph Model & Crowd/Availability Modules
                             : A* Search Algorithm & Cost Calculator
                             : Automated Smoke Tests Validated (100% Pass)
    API & Frontend Build     : FastAPI REST Endpoints & Static Serving
                             : 3-Column Glassmorphism Dark UI
                             : vis-network Graph Initialization & Route Highlighting
                             : Interactive Disruption & Crowd Randomization
    Refinements & Iterations : Header cleanup (Names & course badge removed)
                             : Localized vis-network dependency (Offline resilience)
                             : Map viewport & canvas fit debugging
    Documentation & Roadmap  : Progress & Ideas documentation established
```

### Phase 1: Core Graph Architecture & Backend Modeling ✅
- **`backend/metro_network.json`**: Crafted the complete network topography, defining all 20 stations with 2D pixel coordinates $(x, y)$, line associations, interchange flags, and 20 bidirectional segments with explicit fares and durations.
- **`backend/graph_model.py`**: Built `Station`, `Edge`, and `MetroGraph` classes. Handles adjacency list representations, edge lookups, Euclidean distance calculations, and bidirectional symmetry.

### Phase 2: Algorithmic Implementation ✅
- **`backend/crowd_module.py`**: Created crowd state storage mapping each station to `'low'`, `'medium'`, or `'high'`. Implemented dynamic randomization simulating real-world rush-hour fluctuations.
- **`backend/availability_module.py`**: Built an in-memory toggle registry for station and edge operational statuses. Ensures closed nodes are excluded from search expansion.
- **`backend/cost_calculator.py`**: Coded the unified edge cost equation, dynamic weights processing, crowd/transfer penalty assignments, and the admissible Euclidean distance heuristic.
- **`backend/astar_search.py`**: Constructed the core A* search engine from scratch:
  - Priority queue state management with deterministic tie-breaking.
  - Closed set tracking with pop-time validation.
  - Detailed search trace collection logging every node expansion, including parent, $g(n)$, $h(n)$, and $f(n)$ metrics.
  - Yen's-style K-shortest alternative path finder.
- **`backend/test_smoke.py`**: Automated verification test suite executing 4 key scenarios:
  1. Direct single-line path (West Terminal → East Terminal)
  2. Multi-line transfer path (Airport → Northern Heights)
  3. Disruption rerouting / hard constraint exclusion (closing Central Hub)
  4. Trace step generator verification (19 expansion steps recorded)
  *Result:* **All 4 tests passed with 100% precision.**

### Phase 3: REST API & Integration Layer ✅
- **`backend/api.py`**: FastAPI application exposing clean RESTful endpoints:
  - `GET /api/graph` — Delivers full station data, connections, current crowd levels, and operational statuses.
  - `POST /api/route` — Accepts source, destination, and user weights; executes A* and returns optimal + alternative routes and the full execution trace.
  - `GET /api/crowd` & `POST /api/crowd/randomize` — Queries and triggers live crowd fluctuations.
  - `PUT /api/station/{id}/toggle` & `PUT /api/edge/{from}/{to}/toggle` — Dynamically modifies network availability.
  - `GET /api/status` — Returns system operational status.
  - Static file mounts serving the frontend directly on `http://localhost:8000`.

### Phase 4: Frontend Development & Aesthetics ✅
- **`frontend/index.html`**: Structured 3-column layout adhering to modern web standards, complete with route query form, sliders, preset chips, network canvas, results itinerary, step-by-step trace animator, and disruptions panel.
- **`frontend/style.css`**: Built a sleek dark-mode aesthetic featuring deep charcoal backgrounds (`#0d1117`), cyan/amber neon accents, subtle glassmorphism blur effects (`backdrop-filter`), glowing line indicators, and responsive scrollbars.
- **`frontend/app.js`**: Managed client-side state, API calls, dynamic form validation, route rendering, A* trace animation playback (Play, Pause, Step Forward, Reset), and network node selection.
- **`run.bat`**: Created a Windows startup script for one-click environment setup and server launch.

### Phase 5: User Feedback & UI Adjustments ✅
- **Header Clean-Up:** In response to user direction, removed student names, roll numbers, and the course title ("Fundamentals of Artificial Intelligence") from the header bar, presenting a clean branded interface: AI Metro logo + tagline on the left, action buttons on the right.
- **Offline Asset Management:** Downloaded `vis-network.min.js` (689 KB) directly into `frontend/` to eliminate external CDN dependency failures on offline or firewalled environments.

### Phase 6: Current State & Map Viewport Status ⚠️
- **Backend Health:** 100% operational and verified.
- **Frontend State:** Fully structured and styled.
- **Active Bug:** The center `vis-network` canvas container receives layout dimensions (`936px × 590px`), and `vis.Network` is instantiated with 20 stations, but the initial zoom/pan coordinates require camera stabilization so all nodes render immediately in the center on first load.

### Phase 6: Custom 2D Canvas Engine & High-Res Viewport ✅
- **`frontend/canvas_renderer.js`**: Built a lightweight, high-performance HTML5 Canvas 2D transit rendering engine with device pixel ratio (DPR) retina scaling, multi-layered neon rail tracks, animated train particles traveling along active routes, origin/destination radar pulse markers, and full pan-and-zoom controls.

### Phase 7: Multi-Agent Transit AI Council Debate Modal ✅
- **`backend/api.py`** & **`frontend/app.js`**: Connected `/api/council-debate` to an interactive dialog accessible via navbar and route cards.
- Simulates a 3-way debate among autonomous transit agents:
  - **The Rusher**: Speed and minimal journey duration priority.
  - **The Relaxer**: Passenger comfort and platform congestion avoidance priority.
  - **The Hawk**: Commuter budget and fare minimization priority.
- Features real-time decrypted telemetry transcripts, agent comparison cards, and the **SCADA Dispatcher Compromise Ruling** with a one-click "Apply Compromise Route" action that dynamically loads the consensus route onto the canvas and itinerary.

### Phase 8: Emergency Scenario Deck ✅
- Added instant emergency simulation chips in the left sidebar:
  - ⚡ **Storm Outage**: Shuts down Central Hub & triggers high passenger congestion across detour lines.
  - ⚽ **Match Surge**: Surges crowd to High at Expo Centre and Airport terminals.
  - 🚧 **Track Repair**: Splits Line B tracks between Market Plaza and Riverside.
  - 🟢 **All Clear**: Restores all stations and edges to default operational status and balances crowd levels.
- Automatically triggers adaptive A* path recalculation to demonstrate network resilience.

### Phase 9: Green Transit Eco-Footprint Engine ✅
- Integrated real-time carbon and financial savings calculations into the Recommended Route card:
  - Dynamically calculates $\text{CO}_2$ emissions prevented compared to private gasoline vehicles ($\approx 115\text{g } \text{CO}_2/\text{km}$).
  - Compares commuting cost against private taxi fares ($\approx ₹9.5/\text{min}$ saved).

### Phase 10: AI Metro Smart Token Digital Boarding Pass ✅
- Built a digital holographic transit ticket modal:
  - Displays token serial number, origin ➔ destination terminals, transit lines, duration, fare, transfers, and departure window.
  - Includes a simulated RFID barcode and buttons to **Print Pass** (`window.print()`) or **Copy Route Summary** to clipboard.

---

## 4. Summary Table of Files & Components

| Component | File Path | Status | Role |
|---|---|---|---|
| **Network Data** | `backend/metro_network.json` | ✅ Complete | 20 stations, 24 edges, 3 lines, coordinates |
| **Graph Model** | `backend/graph_model.py` | ✅ Complete | Graph classes, adjacency list, distance formulas |
| **Crowd Engine** | `backend/crowd_module.py` | ✅ Complete | Crowd levels, penalty scores, randomizer, time-shift decay |
| **Availability Engine**| `backend/availability_module.py`| ✅ Complete | Station/edge open/close hard constraints |
| **Cost Calculator** | `backend/cost_calculator.py` | ✅ Complete | 4-part edge cost calculation + admissible $h(n)$ |
| **A\* Search Engine** | `backend/astar_search.py` | ✅ Complete | A* search, state tracking, trace logger, Yen's alt, resilience |
| **API Server** | `backend/api.py` | ✅ Complete | FastAPI REST endpoints, multi-agent debate, time-shift windows |
| **Test Suite** | `backend/test_smoke.py` | ✅ Complete | 7 smoke test scenarios verifying end-to-end logic (100% pass) |
| **Frontend HTML** | `frontend/index.html` | ✅ Complete | Semantic 3-panel UI, Council modal, Smart Token pass |
| **Frontend Styling** | `frontend/style.css` | ✅ Complete | Modern dark theme, glassmorphism, responsive modals |
| **Canvas Engine** | `frontend/canvas_renderer.js` | ✅ Complete | 2D canvas transit map, glowing rails, train particles |
| **Frontend Logic** | `frontend/app.js` | ✅ Complete | API integration, Council modal, Scenarios, Smart Token |
| **Automation** | `run.bat` & `requirements.txt` | ✅ Complete | Automated dependency setup and server start |
| **Documentation** | `README.md` & `progress_and_ideas.md` | ✅ Complete | System architecture, proofs, setup guide, and progress log |

---

## 5. Current Operational Status

- **Backend Health:** 100% operational on `http://127.0.0.1:8000`.
- **Smoke Tests:** 7/7 automated scenarios passing.
- **Frontend State:** Fully verified in headless browser:
  - Custom Canvas transit renderer running at 60 FPS with animated trains and radar beacons.
  - Multi-Agent AI Council Debate fully functional with transcript and compromise route application.
  - Emergency scenario toggles dynamically triggering network rerouting.
  - Digital Boarding Pass modal with print and copy utilities.
  - Departure window predictive forecasting ($T+0$, $T+15$, $T+30$) active.

---
*Created and maintained in the AI Metro Project Repository.*
