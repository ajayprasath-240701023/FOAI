# AI Metro — Crowd-Aware Route Planner

> **Course Project** · Fundamentals of Artificial Intelligence  
> **Team:** Abirami L (240701010) · Ajay Prasath P (240701023)

A full-stack metro route planner driven by **A\* Search** with a dynamic cost function that combines fare, travel time, crowd level, and transfer penalties.

---

## Quick Start (Windows)

```bat
cd ai_metro
run.bat
```

Then open **http://localhost:8000** in your browser.

**Manual start:**
```bash
pip install -r requirements.txt
cd backend
uvicorn api:app --reload
```

---

## Metro Network

| Network | Detail |
|---------|--------|
| Stations | **20** (unique physical stations) |
| Lines | **3** — Blue (horizontal) · Red (vertical) · Green (diagonal) |
| Interchanges | **3** — Central Hub (BL+RL), Market Plaza (BL+GL), Old Town (RL+GL) |
| Edges | **20** bidirectional segments (40 directed copies internally) |

```
Blue Line :  West Terminal → Westwood Park → University Gate →
             ★Central Hub → ★Market Plaza → Riverside → Tech Valley → East Terminal

Red Line  :  Northern Heights → Industrial Zone → Suburban North →
             ★Central Hub → ★Old Town → Harbour View → South Terminal

Green Line:  Airport → Expo Centre → ★Old Town → Cultural Hub →
             ★Market Plaza → Science Park → IT Hub → North Connect
```

---

## Algorithm — A\* Search

### State Representation

```
State = (station_id, current_line)
```

Including the **current line** in the state is essential: arriving at an interchange via the Blue Line and via the Red Line are different states because the onward transfer cost differs.

### Cost Functions

```
f(n) = g(n) + h(n)

g(n) = Σ edge_cost from source to n

edge_cost = cost_weight   × travel_cost
          + time_weight   × travel_time
          + crowd_weight  × crowd_penalty
          + transfer_weight × transfer_penalty
```

| Component | Values |
|-----------|--------|
| `travel_cost` | ₹8–₹18 depending on segment distance |
| `travel_time` | 3–7 minutes per segment |
| `crowd_penalty` | Low=0 · Medium=8 · High=20 |
| `transfer_penalty` | 0 (same line) · 25 (line change) |

### Heuristic — h(n)

```python
h(n) = euclidean_distance(n, goal) × 0.05
```

**Admissibility proof:**  
The shortest physical edge (suburban\_north → central\_hub, ≈75 px) has minimum edge cost = 8+3 = 11 (fare+time, weight=1.0). At weight=0.5 the minimum is 5.5.  
`h(75) = 75 × 0.05 = 3.75 < 5.5` ✓ — h(n) never overestimates, so A\* returns the optimal path.

### Open Set (Priority Queue)

```python
heapq.heappush(open_set, (f, tie_break_counter, station_id, line, g, path_stations, path_lines))
```

`tie_break_counter` is an incrementing integer that resolves equal-f comparisons deterministically without comparing lists.

### Closed Set

```
closed_set = set of (station_id, current_line)
```

A state is closed only when popped (not when pushed), matching canonical A\*.

---

## Availability Filtering (Hard Constraint)

Closed stations and edges are **completely removed from the search space** before A\* runs — they are never merely penalised. This is implemented in `availability_module.py`:

```python
# Inside A* neighbour expansion:
if not availability_module.is_station_available(neighbour_id):
    continue   # skip — not in graph
if not availability_module.is_edge_available(from_id, to_id):
    continue   # skip — not in graph
```

Toggle stations open/closed in the **Disruptions** panel or by double-clicking a station on the map.

---

## Alternative Routes

Uses a Yen's-algorithm-inspired approach:

1. Find optimal path P₁ via A\*
2. For each intermediate station in P₁, re-run A\* with that station temporarily excluded
3. Return the lowest-cost result that differs from P₁

---

## User Preferences (Weight Sliders)

| Slider | Effect |
|--------|--------|
| Fare Weight | Prioritise cheaper routes |
| Time Weight | Prioritise faster routes |
| Crowd Avoidance | Avoid high-crowd stations |
| Transfer Penalty | Prefer fewer line changes |

**Presets:** Fastest · Comfort · Cheapest · Balanced

---

## Departure Time Windows & Predictive Crowd Shift ($t$, $t+15$, $t+30$)

In addition to static or instant crowd snapshots, AI Metro models **dynamic crowd decay and passenger dispersal** across departure windows:
- **Now ($t$)**: Immediate dispatch under current live passenger congestion.
- **$t+15$ min**: Rush-hour transition window; high congestion points decay toward medium density.
- **$t+30$ min**: Post-peak clearance window; significant off-peak clearance toward low crowd index.

The frontend presents a **3-column Forecast Matrix** comparing estimated journey time, comfort index, fares, and transfer requirements, accompanied by an automated Dispatcher Advisory recommendation.

---

## File Structure

```
ai_metro/
├── backend/
│   ├── metro_network.json      ← 20-station graph data
│   ├── graph_model.py          ← Station, Edge, MetroGraph
│   ├── crowd_module.py         ← CrowdModule (Low/Medium/High)
│   ├── availability_module.py  ← hard-constraint exclusion
│   ├── cost_calculator.py      ← edge cost formula + h(n)
│   ├── astar_search.py         ← A* engine with trace
│   └── api.py                  ← FastAPI REST API
├── frontend/
│   ├── index.html              ← 3-column layout
│   ├── style.css               ← dark theme + glassmorphism
│   └── app.js                  ← vis-network + route UI
├── requirements.txt
├── run.bat                     ← one-click start (Windows)
└── README.md
```

---

## API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/api/graph` | Full network + crowd + availability |
| `POST` | `/api/route` | A\* route search |
| `POST` | `/api/crowd/randomize` | Simulate crowd changes |
| `PUT` | `/api/station/{id}/toggle` | Open/close station |
| `PUT` | `/api/edge/{from}/{to}/toggle` | Open/close edge |
| `GET` | `/api/status` | All availability statuses |

---

*Built for evaluation by the course faculty. The A\* implementation is fully inspectable in `backend/astar_search.py` — no black-box library is used.*
